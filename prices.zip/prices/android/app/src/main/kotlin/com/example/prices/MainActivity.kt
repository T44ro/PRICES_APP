package com.example.prices

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
